package by.goncharov.task08.beans;

public class MonocotsFlower extends Flower {
}
